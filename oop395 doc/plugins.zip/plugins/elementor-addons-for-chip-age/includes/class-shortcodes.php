<?php

namespace pritom\ElementorAddonsForChipAge;

class Shortcode {
    /**
     * Shortcode constructor.
    */
    public function __construct() {
        
    }

    
}