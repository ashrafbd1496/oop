<?php

namespace Pritom\SkillTestForWp\Admin;
class Admin_Menu{
	/**
	 * Admin Menu constructor.
	 */

	public function __construct(){
		
	}


}
