<?php

namespace Pritom\SkillTestForWp\Admin;

class MetaBox{
	/**
	 * MetaBox constructor.
	 */

	public function __construct(){
		
	}


}
