<?php  

	
	/**
	 * All class load
	 */
	include_once "DB.php";
	include_once "Management.php";
	include_once "Student.php";


	



?>