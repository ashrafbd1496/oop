<?php  


	/**
	 * All managaements functions 
	 */
	class Management
	{
		
		
	}







?>