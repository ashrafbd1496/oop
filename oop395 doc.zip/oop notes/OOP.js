
    // Object Oriented Programming - PHP 
    
        - What is OOP & Why 
        - class & Object 
        - property & Method 
        - Use property & Method out of a class 
        - Use property & Method in of a class 
        - static method & property & its use 
        - OOP constant 
        - constract & Destract 
        - Inheritance / Extends 
        - Acess Modifier
        - abstract class 
        - Final class & final Method 
        - Interface & Implements 
        - Traits 
        - Magic methods 
        - Namespace 
        - Autoloading class 
        - PSR-4 - project orientation 
        - CRUD by OOP 
        - OOP Project - educationboardresult 
        
 
